package com.vijay.payment.ms.validation.model;

public class PaymentResponse {

    private String transactionID;

    private boolean isValidationDone;

    private boolean isEnrichmentDone;

    private boolean isSanctionDone;

    private boolean isFullfilmentDone;

    public PaymentResponse(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public boolean isValidationDone() {
        return isValidationDone;
    }

    public void setValidationDone(boolean validationDone) {
        isValidationDone = validationDone;
    }

    public boolean isEnrichmentDone() {
        return isEnrichmentDone;
    }

    public void setEnrichmentDone(boolean enrichmentDone) {
        isEnrichmentDone = enrichmentDone;
    }

    public boolean isSanctionDone() {
        return isSanctionDone;
    }

    public void setSanctionDone(boolean sanctionDone) {
        isSanctionDone = sanctionDone;
    }

    public boolean isFullfilmentDone() {
        return isFullfilmentDone;
    }

    public void setFullfilmentDone(boolean fullfilmentDone) {
        isFullfilmentDone = fullfilmentDone;
    }

    @Override
    public String toString() {
        return "PaymentResponse{" +
                "transactionID='" + transactionID + '\'' +
                ", isValidationDone=" + isValidationDone +
                ", isEnrichmentDone=" + isEnrichmentDone +
                ", isSanctionDone=" + isSanctionDone +
                ", isFullfilmentDone=" + isFullfilmentDone +
                '}';
    }
}
