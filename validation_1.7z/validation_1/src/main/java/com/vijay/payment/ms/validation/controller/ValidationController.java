package com.vijay.payment.ms.validation.controller;

import java.util.UUID;
import com.vijay.payment.ms.validation.model.PaymentRequest;
import com.vijay.payment.ms.validation.model.PaymentResponse;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/validation")
public class ValidationController {


//    @GetMapping(value="/{message}")
//    public String helloMessage(@PathVariable("message") String message){
//        return "Hello world " + message;
//    }

    @GetMapping("/hello")
    public String helloMessage(){
        return "Hello world Spring";
    }

    @PostMapping("/validatePayment")
    public PaymentResponse validatePayment(@RequestBody PaymentRequest paymentRequest){
        String transactionID = UUID.randomUUID().toString();
        PaymentResponse response = new PaymentResponse(transactionID);
        response.setValidationDone(true);
        return response;
    }




}
