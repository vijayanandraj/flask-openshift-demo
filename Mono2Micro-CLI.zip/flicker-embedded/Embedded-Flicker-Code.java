import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ContextWriter {
	
	private final List<Test> tests = Collections.synchronizedList(new ArrayList<>());
	
	private static long getMilli()
	{
		return ZonedDateTime.now().toInstant().toEpochMilli();
	}
	
	public interface Test {
		public void stop();
	}

	public Test start(final String label) {
		return new Test() {
			
			private final long start = getMilli();
			private long stop;
			private AtomicBoolean complete = new AtomicBoolean(false);
			
			@Override
			public void stop() {
				if (complete.compareAndSet(false, true)) {
					stop = getMilli();
					tests.add(this);
				}
			}
			
			@Override
			public String toString() {
				StringBuilder sb = new StringBuilder();
				sb.append("{\"STOP\":");
				sb.append(stop);
				sb.append(",\"LABEL\":\"");
				sb.append(label);
				sb.append("\",\"START\":");
				sb.append(start);
				sb.append('}');
				return sb.toString();
			}
		};
	}
	
	public void write(File file) throws IOException {
		Writer w = new FileWriter(file);
		try {
			write(w);
		}
		finally {
			w.close();
		}
	}
	
	public void write(Writer writer) throws IOException {
		String s = toString();
		writer.write(s, 0, s.length());
		writer.flush();
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[{\"offset\":0,\"session\":[");
		boolean first = true;
		for (Test t : tests) {
			if (!first) {
				sb.append(',');
			}
			sb.append(t.toString());
			first = false;
		}
		sb.append("],\"appserver\":\"\"}]");
		return sb.toString();
	}
}