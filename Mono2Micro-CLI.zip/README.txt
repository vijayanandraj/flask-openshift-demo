https://www.ibm.com/docs/mono2micro
