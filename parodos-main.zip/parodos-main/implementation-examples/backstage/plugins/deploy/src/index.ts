export { deployPlugin, DeployPage } from './plugin';
