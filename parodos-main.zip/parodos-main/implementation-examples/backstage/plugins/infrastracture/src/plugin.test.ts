import { infrastructurePlugin } from './plugin';

describe('infrastructure', () => {
  it('should export plugin', () => {
    expect(infrastructurePlugin).toBeDefined();
  });
});
