export { infrastructurePlugin, InfrastructurePage } from './plugin';
