import { notificationPlugin } from './plugin';

describe('notification', () => {
  it('should export plugin', () => {
    expect(notificationPlugin).toBeDefined();
  });
});
