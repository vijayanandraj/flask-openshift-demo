export { trainingPlugin, TrainingPage } from './plugin';
