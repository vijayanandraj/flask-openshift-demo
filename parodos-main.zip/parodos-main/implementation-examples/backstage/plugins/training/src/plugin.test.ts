import { trainingPlugin } from './plugin';

describe('training', () => {
  it('should export plugin', () => {
    expect(trainingPlugin).toBeDefined();
  });
});
