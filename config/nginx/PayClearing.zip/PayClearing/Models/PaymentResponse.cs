﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PaymentClearing.Models
{
    public class PaymentResponse
    {
 
        public string transactionID { get; set; }

        public bool isPaymentProcesssDone { get; set; }

        public string paymentProcessCorrelationID { get; set; }

        public bool isPaymentClearingDone { get; set; }

        public string paymentClearingCorrelationID { get; set; }

        public override string ToString()
        {
            return base.ToString() + "-" + transactionID + "-" 
                + isPaymentProcesssDone + "-" + paymentProcessCorrelationID +
                "-" + isPaymentProcesssDone + "-" + paymentClearingCorrelationID;
        }
    }
}
