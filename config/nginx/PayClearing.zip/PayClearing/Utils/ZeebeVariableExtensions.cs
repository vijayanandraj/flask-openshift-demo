﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace PaymentClearing.Utils
{
    public class ZeebeVariableExtensions
    {
        public static T ConvertVariablesAsType<T>(string variables, JsonSerializerSettings settings = null) where T : class
        {
            return JsonConvert.DeserializeObject<T>(variables, settings);
        }

        public static string ConvertTypeAsVariableString(object payload, JsonSerializerSettings settings = null)
        {
            return JsonConvert.SerializeObject(payload, settings);
        }
    }
}
