using System.Threading.Tasks;
using PaymentClearing.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using fastJSON;
using PaymentClearing.Utils;
using PaymentClearing.Models;

namespace PaymentClearing.Controllers
{
    public class PaymentClearingController : Controller
    {
        private readonly ILogger<PaymentClearingController> _logger;
        private readonly IZeebePaymentClearingService _zeebeService;

        public PaymentClearingController(ILogger<PaymentClearingController> logger, IZeebePaymentClearingService zeebeService)
        {
            _logger = logger;
            _zeebeService = zeebeService;
        }

        [Route("/status")]
        [HttpGet]
        public async Task<string> Get()
        {
            return (await _zeebeService.Status()).ToString();
        }
               
    }
}
