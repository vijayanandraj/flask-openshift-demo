﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;
using PaymentClearing.Models;
using NLog;
using Zeebe.Client.Api.Worker;
using Zeebe.Client.Api.Responses;
using PaymentClearing.Utils;


namespace PaymentClearing.Services
{
    public class PaymentClearingServices
    {
        private Logger logger = LogManager.GetCurrentClassLogger();

        public PaymentResponse processPayment(PaymentRequest paymentRequest, PaymentResponse response)
        {
            PaymentResponse paymentResponse = null;
            logger.Info("Payment request to String " + paymentRequest.ToString());
            Thread.Sleep(100);
            response.isPaymentClearingDone = true;
            response.paymentClearingCorrelationID = "Clearing-" + response.transactionID;
            paymentResponse = response;
            logger.Info("Payment response to String " + paymentResponse.ToString());
            return paymentResponse;
        }

        


    }
}
