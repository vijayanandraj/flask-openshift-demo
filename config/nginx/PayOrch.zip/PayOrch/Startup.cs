using System;
using PayOrch.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NLog;

namespace PayOrch
{
    public class Startup
    {
        private static readonly Logger logger = LogManager.GetCurrentClassLogger();


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<IZeebeService, ZeebeService>();
            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            var zeebeService = app.ApplicationServices.GetService<IZeebeService>();

            zeebeService.Deploy("payment.bpmn");
            zeebeService.StartWorkers();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

         
            app.UseRouting();
                       
            app.UseEndpoints(endpoints => { endpoints.MapControllers(); });
        }
    }
}
