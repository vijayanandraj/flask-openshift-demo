using System.Threading.Tasks;
using System;
using PayOrch.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using fastJSON;
using PayOrch.Utils;
using PayOrch.Models;

namespace PayOrch.Controllers
{
    public class PaymentController : Controller
    {
        private readonly ILogger<PaymentController> _logger;
        private readonly IZeebeService _zeebeService;

        public PaymentController(ILogger<PaymentController> logger, IZeebeService zeebeService)
        {
            _logger = logger;
            _zeebeService = zeebeService;
        }

        [Route("/status")]
        [HttpGet]
        public async Task<string> Get()
        {
            return (await _zeebeService.Status()).ToString();
        }


        [Route("/payment")]
        [HttpPost]
        public async Task<PaymentResponse> makePayment([FromBody] PaymentRequest model)
        {
            _logger.LogInformation("Payment request pay load " + model.ToString());
            int tranId = new Random().Next(10000, 99999);
            PaymentResponse paymentResponse = new PaymentResponse();
            paymentResponse.transactionID = "pay-" + tranId;
            PaymentDTO workFlowInstanceVariable = new PaymentDTO();
            workFlowInstanceVariable.paymentRequest = model;
            workFlowInstanceVariable.paymentResponse = paymentResponse;
            string variableString = ZeebeVariableExtensions.ConvertTypeAsVariableString(workFlowInstanceVariable);
            _logger.LogInformation("Input payload String ==> " + variableString);
            var instance = await _zeebeService.StartWorkflowInstance("payment", variableString);
            _logger.LogInformation("Result String ==> " + instance);
            PaymentDTO result = ZeebeVariableExtensions.ConvertVariablesAsType<PaymentDTO>(instance);
            return result.paymentResponse;
        }


        //[Route("/start")]
        //[HttpPost]
        //public async Task<string> StartWorkflowInstance()
        //{
        //    var instance = await _zeebeService.StartWorkflowInstance("payment");
        //    return instance;
        //}
    }
}
