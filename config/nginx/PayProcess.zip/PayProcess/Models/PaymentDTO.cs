﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayProcess.Models
{
    public class PaymentDTO
    {
        public PaymentRequest paymentRequest { get; set; }
        public PaymentResponse paymentResponse { get; set; }

        public override string ToString()
        {
            return base.ToString() + "-" + paymentRequest.ToString() + "-" + paymentResponse.ToString();
        }
    }
}
