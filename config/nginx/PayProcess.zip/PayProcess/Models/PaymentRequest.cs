﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PayProcess.Models
{
    public class PaymentRequest
    {
        public string fromAccountNumber { get; set; }
        public string toAccountNumber { get; set; }
        public double amount { get; set; }

        public override string ToString()
        {
            return base.ToString() + "-" + fromAccountNumber + "-" + toAccountNumber + "-" + amount;
        }
    }
}
