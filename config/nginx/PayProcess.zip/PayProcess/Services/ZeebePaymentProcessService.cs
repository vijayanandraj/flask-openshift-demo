using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
//using fastJSON;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Zeebe.Client;
using Zeebe.Client.Api.Responses;
using Zeebe.Client.Api.Worker;
using Zeebe.Client.Impl.Builder;
using NLog.Extensions.Logging;
using PayProcess.Utils;
using PayProcess.Models;
using PayProcess.Services;

namespace PayProcess.Services
{

    public interface IZeebePaymentProcessService
    {

        public Task<ITopology> Status();
       
        public void StartWorkers();

        //public void createWorker(IZeebeClient client, string jobType, JobHandler jobHandler);
    }

    //public class MakeGreetingCustomHeadersDto
    //{
    //    public string greeting { get; set; }
    //}

    //public class MakeGreetingVariablesDTO
    //{
    //    public string name { get; set; }
    //}
    
    public class ZeebePaymentProcessService: IZeebePaymentProcessService
    {
        private readonly IZeebeClient _client;
        private readonly ILogger<ZeebePaymentProcessService> _logger;

        public ZeebePaymentProcessService(ILogger<ZeebePaymentProcessService> logger)
        {

            _logger = logger;

            _client =
                ZeebeClient.Builder()
                    .UseLoggerFactory(new NLogLoggerFactory())
                    .UseGatewayAddress("127.0.0.1:26500")
                    .UsePlainText().Build();      
        }

        public void StartWorkers()
        {
            createPaymentProcessWorker();
     
        }

        public Task<ITopology> Status()
        {
            return _client.TopologyRequest().Send();
        }

 
        public  void createPaymentProcessWorker()
        {
            _createWorker("process", async (client, job) =>
             {
                PaymentDTO payload = ZeebeVariableExtensions.ConvertVariablesAsType<PaymentDTO>(job.Variables);
                PaymentRequest request = payload.paymentRequest;
                _logger.LogInformation("Payment request ==> " + request.ToString());
                PaymentResponse response = payload.paymentResponse;
                _logger.LogInformation("Payment response before process ==> " + response.ToString());
                PaymentResponse paymentResponse = new PaymentServices().processPayment(request, response);
                payload.paymentResponse = paymentResponse;
                string responseVariableAsString = ZeebeVariableExtensions.ConvertTypeAsVariableString(payload);
                _logger.LogInformation("Payload response string after payment process ==> " + responseVariableAsString);
                await client.NewCompleteJobCommand(job.Key).Variables(responseVariableAsString).Send();
                _logger.LogInformation("Process job completed");

            });
        }

        private void _createWorker(string jobType, JobHandler jobHandler)
        {
            _client.NewWorker()
                    .JobType(jobType)
                    .Handler(jobHandler)
                    .MaxJobsActive(5)
                    .Name(jobType)
                    .PollInterval(TimeSpan.FromSeconds(50))
                    .PollingTimeout(TimeSpan.FromSeconds(50))
                    .Timeout(TimeSpan.FromSeconds(10))
                    .Open();
        }

        private IConfiguration Configuration { get; set; }
    }
}
