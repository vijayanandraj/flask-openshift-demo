using System.Threading.Tasks;
using PayProcess.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using fastJSON;
using PayProcess.Utils;
using PayProcess.Models;

namespace PayProcess.Controllers
{
    public class PaymentProcessController : Controller
    {
        private readonly ILogger<PaymentProcessController> _logger;
        private readonly IZeebePaymentProcessService _zeebeService;

        public PaymentProcessController(ILogger<PaymentProcessController> logger, IZeebePaymentProcessService zeebeService)
        {
            _logger = logger;
            _zeebeService = zeebeService;
        }

        [Route("/status")]
        [HttpGet]
        public async Task<string> Get()
        {
            return (await _zeebeService.Status()).ToString();
        }


        //[Route("/process")]
        //[HttpPost]
        //public async Task<PaymentResponse> processPayment([FromBody] PaymentRequest model)
        //{
        //    _logger.LogInformation("Payment request pay load " + model.ToString());
        //    string variableString = ZeebeVariableExtensions.ConvertTypeAsVariableString(model);
        //    var instance = await _zeebeService.StartWorkflowInstance("payment", variableString);
        //    _logger.LogInformation("Result String ==> " + instance);
        //    PaymentResponse response = ZeebeVariableExtensions.ConvertVariablesAsType<PaymentResponse>(instance);
        //    return response;
        //}


        //[Route("/start")]
        //[HttpPost]
        //public async Task<string> StartWorkflowInstance()
        //{
        //    var instance = await _zeebeService.StartWorkflowInstance("payment");
        //    return instance;
        //}
    }
}
